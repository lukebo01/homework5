INDEX_KEY = "idx"
TEXT_LEFT = "text_left"
TEXT_RIGHT = "text_right"
LABEL = "label"
